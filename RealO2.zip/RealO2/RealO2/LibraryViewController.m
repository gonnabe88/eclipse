//
//  LibraryViewController.m
//  RealO2
//
//  Created by JANG on 13. 1. 18..
//  Copyright (c) 2013년 JANG. All rights reserved.
//

#import "LibraryViewController.h"
#import "ViewCell.h"
#import "WebViewController.h"
#import "TFHpple.h"
#import "TFHppleElement.h"


@interface LibraryViewController ()

@end

@implementation LibraryViewController
@synthesize tView, where, URLTEST;
- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    tView.delegate = self;
    tView.dataSource = self;
    where = [[NSArray alloc] initWithArray:[self creatLibraryInfo]];
    
}
-(NSArray *)creatLibraryInfo {
    NSArray *array;
    
    NSString *one,*two,*three,*four,*five;
    NSArray *elements1;
    NSArray *elements2;
    NSString *tutorialsXpathQueryString1= @"//td[@class='rest_s']";;
    NSString *tutorialsXpathQueryString2= @"//td[@class='total_s']";;
    
    /*제 1열람실 현황*/
    NSString * html1= [[NSString stringWithContentsOfURL:[NSURL URLWithString:@"http://210.123.38.73/syslib/1_count.asp"] encoding:-2147481280 error:nil] stringByReplacingOccurrencesOfString:@"\n" withString:@"" ];
    NSData *htmlData1 = [html1 dataUsingEncoding:NSUnicodeStringEncoding];
    
    TFHpple *parser1 = [TFHpple hppleWithHTMLData:htmlData1];
    
    elements1 = [parser1 searchWithXPathQuery:tutorialsXpathQueryString1];
    elements2 = [parser1 searchWithXPathQuery:tutorialsXpathQueryString2];
    
    for (TFHppleElement *element in elements1)
    {
        NSArray *temp = [element children];
        for(TFHppleElement *ee in temp)
        {
            one = [ee content];
            NSLog(@"%@",[ee content]);
        }
        
    }
    for (TFHppleElement *element in elements2)
    {
        NSArray *temp = [element children];
        for(TFHppleElement *ee in temp)
        {
            one = [one stringByAppendingString:@" / "];
            one = [one stringByAppendingString:[ee content]];
        }
        
    }
    NSDictionary *a = [NSDictionary dictionaryWithObjectsAndKeys:@"지하열람실",@"where",
                       @"http://210.123.38.73/syslib/1_readingroom.asp",@"url",
                      one,@"count", nil];
    
    
    /*제 2열람실 현황*/ 
    NSString * html2= [[NSString stringWithContentsOfURL:[NSURL URLWithString:@"http://210.123.38.73/syslib/2_count.asp"] encoding:-2147481280 error:nil] stringByReplacingOccurrencesOfString:@"\n" withString:@"" ];
    NSData *htmlData2 = [html2 dataUsingEncoding:NSUnicodeStringEncoding];
    
    TFHpple *parser2 = [TFHpple hppleWithHTMLData:htmlData2];
    
    elements1 = [parser2 searchWithXPathQuery:tutorialsXpathQueryString1];
    elements2 = [parser2 searchWithXPathQuery:tutorialsXpathQueryString2];
    
    for (TFHppleElement *element in elements1)
    {
        NSArray *temp = [element children];
        for(TFHppleElement *ee in temp)
        {
            two = [ee content];
            NSLog(@"%@",[ee content]);
        }
        
    }
    for (TFHppleElement *element in elements2)
    {
        NSArray *temp = [element children];
        for(TFHppleElement *ee in temp)
        {
            two = [two stringByAppendingString:@" / "];
            two = [two stringByAppendingString:[ee content]];
        }
        
    }
    NSDictionary *b = [NSDictionary dictionaryWithObjectsAndKeys:@"제 2열람실",@"where",
                       @"http://210.123.38.73/syslib/2_readingroom.asp",@"url",
                       two,@"count", nil];
    

    /*제 4열람실*/
    NSString * html3= [[NSString stringWithContentsOfURL:[NSURL URLWithString:@"http://210.123.38.73/syslib/3_count.asp"] encoding:-2147481280 error:nil] stringByReplacingOccurrencesOfString:@"\n" withString:@"" ];
    NSData *htmlData3 = [html3 dataUsingEncoding:NSUnicodeStringEncoding];
    
    TFHpple *parser3 = [TFHpple hppleWithHTMLData:htmlData3];
    
    elements1 = [parser3 searchWithXPathQuery:tutorialsXpathQueryString1];
    elements2 = [parser3 searchWithXPathQuery:tutorialsXpathQueryString2];
    
    for (TFHppleElement *element in elements1)
    {
        NSArray *temp = [element children];
        for(TFHppleElement *ee in temp)
        {
            three = [ee content];
            NSLog(@"%@",[ee content]);
        }
        
    }
    for (TFHppleElement *element in elements2)
    {
        NSArray *temp = [element children];
        for(TFHppleElement *ee in temp)
        {
            three = [three stringByAppendingString:@" / "];
            three = [three stringByAppendingString:[ee content]];
        }
        
    }

    NSDictionary *c = [NSDictionary dictionaryWithObjectsAndKeys:@"제 4열람실",@"where",
                       @"http://210.123.38.73/syslib/3_readingroom.asp",@"url",
                       three,@"count", nil];
    
    /*대학원 열람실 현황*/
    NSString * html4= [[NSString stringWithContentsOfURL:[NSURL URLWithString:@"http://210.123.38.73/syslib/4_count.asp"] encoding:-2147481280 error:nil] stringByReplacingOccurrencesOfString:@"\n" withString:@"" ];
    NSData *htmlData4 = [html4 dataUsingEncoding:NSUnicodeStringEncoding];
    
    TFHpple *parser4 = [TFHpple hppleWithHTMLData:htmlData4];
    
    elements1 = [parser4 searchWithXPathQuery:tutorialsXpathQueryString1];
    elements2 = [parser4 searchWithXPathQuery:tutorialsXpathQueryString2];
    
    for (TFHppleElement *element in elements1)
    {
        NSArray *temp = [element children];
        for(TFHppleElement *ee in temp)
        {
            four = [ee content];
            NSLog(@"%@",[ee content]);
        }
        
    }
    for (TFHppleElement *element in elements2)
    {
        NSArray *temp = [element children];
        for(TFHppleElement *ee in temp)
        {
            four = [four stringByAppendingString:@" / "];
            four = [four stringByAppendingString:[ee content]];
        }
        
    }
    
    NSDictionary *d = [NSDictionary dictionaryWithObjectsAndKeys:@"대학원열람실(대학원생 전용)",@"where",
                       @"http://210.123.38.73/syslib/4_readingroom.asp",@"url",
                      four,@"count", nil];
    /*2대학원열람실*/
    NSString * html5= [[NSString stringWithContentsOfURL:[NSURL URLWithString:@"http://210.123.38.73/syslib/5_count.asp"] encoding:-2147481280 error:nil] stringByReplacingOccurrencesOfString:@"\n" withString:@"" ];
    NSData *htmlData5 = [html5 dataUsingEncoding:NSUnicodeStringEncoding];
    
    TFHpple *parser5 = [TFHpple hppleWithHTMLData:htmlData5];
    
    elements1 = [parser5 searchWithXPathQuery:tutorialsXpathQueryString1];
    elements2 = [parser5 searchWithXPathQuery:tutorialsXpathQueryString2];
    
    for (TFHppleElement *element in elements1)
    {
        NSArray *temp = [element children];
        for(TFHppleElement *ee in temp)
        {
            five = [ee content];
            NSLog(@"%@",[ee content]);
        }
        
    }
    for (TFHppleElement *element in elements2)
    {
        NSArray *temp = [element children];
        for(TFHppleElement *ee in temp)
        {
            five = [five stringByAppendingString:@" / "];
            five = [five stringByAppendingString:[ee content]];
        }
        
    }
    NSDictionary *e = [NSDictionary dictionaryWithObjectsAndKeys:@"대학원열람실(학부생 이용)",@"where",
                       @"http://210.123.38.73/syslib/5_readingroom.asp",@"url",
                      five,@"count", nil];
    
    array = [NSArray arrayWithObjects:a,b,c,d,e, nil];
    
    
    return array;
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    return [where count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell1";
    ViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    // Configure the cell...
    NSDictionary *data = [where objectAtIndex:[indexPath row]];
    
    cell.libName.text = [data valueForKey:@"where"];
    cell.url.text = [data valueForKey:@"url"];
    cell.currentChair.text = [data valueForKey:@"count"];
    return cell;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 81.0f;
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString:@"Web_View"]) {
        WebViewController *Controller = (WebViewController *)[segue destinationViewController];
        Controller.tempString = ((ViewCell *)sender).url.text;
        
    }
}





#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    /*  WebViewController *detailViewController = [[WebViewController alloc] initWithNibName:@"WebViewController" bundle:nil];
     // ...
     // Pass the selected object to the new view controller.
     
     [self.navigationController pushViewController:detailViewController animated:YES];
     [detailViewController release];
     */
}

@end
