//
//  WebViewController.h
//  RealO2
//
//  Created by JANG on 13. 1. 18..
//  Copyright (c) 2013년 JANG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WebViewController : UIViewController{
    NSString *urlString;
}

- (IBAction)barButtonClick :(UIBarButtonItem *)sender;


@property (strong, nonatomic) IBOutlet UITabBar *Toolbar;
@property (retain, nonatomic) NSString *tempString;
@property (strong, nonatomic) IBOutlet UIWebView *web;
@property (nonatomic, retain) UITextView *tempTest;



@end