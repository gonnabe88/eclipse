//
//  ViewCell.h
//  RealO2
//
//  Created by JANG on 13. 1. 18..
//  Copyright (c) 2013년 JANG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewCell : UITableViewCell{
    IBOutlet UITextView *libName;
    IBOutlet UITextView *url;
    IBOutlet UITextView *currentChair;
    
    IBOutlet UILabel    *foodcort;
    IBOutlet UILabel    *foods;
}
@property (nonatomic, retain) UITextView *libName;
@property (nonatomic, retain) UITextView *url;
@property (nonatomic, retain) UITextView *currentChair;

@property (nonatomic, retain)   UILabel *foodcort;
@property (nonatomic, retain)   UILabel *foods;
@end
