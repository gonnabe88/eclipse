//
//  ViewCell.m
//  RealO2
//
//  Created by JANG on 13. 1. 18..
//  Copyright (c) 2013년 JANG. All rights reserved.
//

#import "ViewCell.h"

@implementation ViewCell

@synthesize currentChair, url, libName;
@synthesize foodcort,foods;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
