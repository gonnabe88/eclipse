//
//  WebViewController.m
//  RealO2
//
//  Created by JANG on 13. 1. 18..
//  Copyright (c) 2013년 JANG. All rights reserved.
//

#import "WebViewController.h"


#define TAG         40

enum buttonTag{
    ENUM_TAG = 40
};

@interface WebViewController ()

@end

@implementation WebViewController
@synthesize tempString, web, Toolbar;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    urlString = [NSString stringWithString:tempString];
    NSURL *library = [[NSURL alloc] initWithString:tempString];
    NSURLRequest *request = [[NSURLRequest alloc]initWithURL:library];
    
    [web loadRequest:request];

}

-(IBAction)barButtonClick:(UIBarButtonItem *)sender{
    NSInteger buttonTag = [sender tag];
    
    switch (buttonTag) {
        case ENUM_TAG:
            if ([web isLoading]) {
                [web stopLoading];
            }else{
                [web reload];
            }
            break;
            
        default:
            break;
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
