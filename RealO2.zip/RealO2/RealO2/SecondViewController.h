//
//  SecondViewController.h
//  RealO2
//
//  Created by JANG on 13. 1. 18..
//  Copyright (c) 2013년 JANG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SecondViewController : UIViewController

@property (nonatomic, strong) NSMutableArray *mon;

@property (retain, nonatomic) NSString *tempString;
@property (strong, nonatomic) IBOutlet UIWebView *web;

@end
