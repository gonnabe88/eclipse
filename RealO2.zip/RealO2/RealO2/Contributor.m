//
//  Contributor.m
//  HTMLParsing
//
//  Created by Matt Galloway on 20/05/2012.
//  Copyright (c) 2012 Swipe Stack Ltd. All rights reserved.
//

#import "Contributor.h"

@implementation Contributor

@synthesize name = _name;
@synthesize url = _url;
@synthesize imageUrl = _imageUrl;

@end
