//
//  O2InfoViewController.h
//  RealO2
//
//  Created by JANG on 13. 1. 28..
//  Copyright (c) 2013년 JANG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface O2InfoViewController : UIViewController
@property (strong, nonatomic) IBOutlet UIWebView *web;
@end
