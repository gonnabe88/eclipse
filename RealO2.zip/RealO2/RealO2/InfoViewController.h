//
//  InfoViewController.h
//  RealO2
//
//  Created by JANG on 13. 1. 27..
//  Copyright (c) 2013년 JANG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface InfoViewController : UITableViewController{
    NSArray *data1;
    NSArray *data2;
    IBOutlet UINavigationController* mainNavi;
}

@end
