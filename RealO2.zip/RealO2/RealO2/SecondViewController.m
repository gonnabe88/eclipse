//
//  SecondViewController.m
//  RealO2
//
//  Created by JANG on 13. 1. 18..
//  Copyright (c) 2013년 JANG. All rights reserved.
//

#import "SecondViewController.h"
#import "TFHpple.h"
@interface SecondViewController ()

@end

@implementation SecondViewController
@synthesize mon,web;


- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.mon = [[NSMutableArray alloc]init];
    
    
    NSString *tutorialsUrl = [[NSString stringWithContentsOfURL:[NSURL URLWithString:@"http://kmucoop.kookmin.ac.kr/restaurant/restaurant.php?w=1"] encoding:-2147481280 error:nil] stringByReplacingOccurrencesOfString:@"<br />" withString:@"" ];
    
    tutorialsUrl=[tutorialsUrl stringByReplacingOccurrencesOfString:@"<br>" withString:@""];
    NSData *tutorialsHtmlData = [tutorialsUrl dataUsingEncoding:NSUnicodeStringEncoding];

    TFHpple *tutorialsParser = [TFHpple hppleWithHTMLData:tutorialsHtmlData];

    NSString *tutorialsXpathQueryString = @"//td[@bgcolor='#eaffd9']//table//tr//td[@class='ft1']";
    NSArray *tutorialsNodes = [tutorialsParser searchWithXPathQuery:tutorialsXpathQueryString];
    NSString *ll;
    
    NSString *food = @"//td[@class='mn_corn']";
    NSArray *foodNode = [tutorialsParser searchWithXPathQuery:food];
    
    NSString *day = @"//span[@style='color:000000;font-weight:bold;']";
    NSArray *dayNode = [tutorialsParser searchWithXPathQuery:day];
    for(TFHppleElement *ele in dayNode) {
        NSLog(@"%@", [[ele firstChild] content]);
    }
    
    for(TFHppleElement *ele in foodNode) {
        NSLog(@"%@", [[ele firstChild] content]);
    }
    
    for (TFHppleElement *element in tutorialsNodes)
    {
        NSArray *temp = [element children];
        for(TFHppleElement *ee in temp)
        {
            if([ee content])
            {
                ll = [ee content];
                ll = [[ll componentsSeparatedByCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] componentsJoinedByString:@""];

                [mon addObject:ll];
            }
        }
        
    }
    for (int i = 0 ; i < [mon count]; i++) {
        NSLog(@"%@", [mon objectAtIndex:i]);
    }
    
    NSURL *foodcort = [[NSURL alloc] initWithString:@"http://m.kookmin.ac.kr/info/cafeteria.php"];
    NSURLRequest *request = [[NSURLRequest alloc]initWithURL:foodcort];
    
    [web loadRequest:request];
    


}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
