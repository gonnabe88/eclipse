//
//  Tutorial.m
//  HTMLParsing
//
//  Created by Matt Galloway on 20/05/2012.
//  Copyright (c) 2012 Swipe Stack Ltd. All rights reserved.
//

#import "Tutorial.h"

@implementation Tutorial

@synthesize title = _title;
@synthesize url = _url;

@end
