//
//  HanwoolViewController.h
//  RealO2
//
//  Created by JANG on 13. 1. 24..
//  Copyright (c) 2013년 JANG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HanwoolViewController : UITableViewController
{
    UITableView *tView;
    NSArray *cellinfo;
}

@property(retain, nonatomic) IBOutlet UITableView *tView;
@property(readonly) IBOutlet  NSArray  *cellinfo;
@property(retain, nonatomic) NSString *day;
@property(retain, nonatomic) NSString *foodCort;
@property(retain, nonatomic) NSString *foods;

-(NSArray *)createFoodInfo;

@end
