//
//  O2InfoViewController.m
//  RealO2
//
//  Created by JANG on 13. 1. 28..
//  Copyright (c) 2013년 JANG. All rights reserved.
//

#import "O2InfoViewController.h"

@interface O2InfoViewController ()

@end

@implementation O2InfoViewController
@synthesize web;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    NSURL *library = [[NSURL alloc] initWithString:@"http://www.naver.com"];
    NSURLRequest *request = [[NSURLRequest alloc]initWithURL:library];
    
    [web loadRequest:request];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
