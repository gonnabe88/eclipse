//
//  LibraryViewController.h
//  RealO2
//
//  Created by JANG on 13. 1. 18..
//  Copyright (c) 2013년 JANG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LibraryViewController : UITableViewController{
    NSArray *where;
    UITableView *tView;
}

@property(retain, nonatomic) IBOutlet UITableView *tView;
@property(readonly) IBOutlet NSArray *where;
 
@property(retain, nonatomic) NSString *URLTEST;
-(NSArray *) creatLibraryInfo;
@end
