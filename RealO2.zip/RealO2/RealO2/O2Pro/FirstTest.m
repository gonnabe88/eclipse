//
//  FirstTest.m
//  o2
//
//  Created by JANG on 13. 1. 11..
//  Copyright (c) 2013년 JANG. All rights reserved.
//

#import "FirstTest.h"


@implementation FirstTest
@synthesize firstTest;
@synthesize data;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    NSArray *temp = [[[NSArray alloc] initWithObjects:@"test1",@"test2",@"test3", nil] autoContentAccessingProxy];
    self.data = temp;
}
- (void)dealloc {
    [data release];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
