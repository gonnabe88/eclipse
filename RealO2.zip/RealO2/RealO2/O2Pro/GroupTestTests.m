//
//  GroupTestTests.m
//  GroupTestTests
//
//  Created by JANG on 13. 1. 13..
//  Copyright (c) 2013년 JANG. All rights reserved.
//

#import "GroupTestTests.h"

@implementation GroupTestTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in GroupTestTests");
}

@end
