//
//  GroupTestTests.h
//  GroupTestTests
//
//  Created by JANG on 13. 1. 13..
//  Copyright (c) 2013년 JANG. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface GroupTestTests : SenTestCase

@end
