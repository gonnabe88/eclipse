//
//  FirstTest.h
//  o2
//
//  Created by JANG on 13. 1. 11..
//  Copyright (c) 2013년 JANG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FirstTest : UIViewController <UITableViewDelegate, UITableViewDataSource>{
    IBOutlet UITableView *firstTest;
    NSArray *data;
}

@property (nonatomic, retain) UITableView * firstTest;
@property (nonatomic, retain) NSArray *data;

@end
