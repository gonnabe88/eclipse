//
//  ViewCell.h
//  O2Pro
//
//  Created by JANG on 13. 1. 13..
//  Copyright (c) 2013년 JANG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewCell : UITableViewCell
{
    IBOutlet UIImageView *usrImage;
    IBOutlet UITextView *usrName;
    IBOutlet UITextView *usrPart;
    
    IBOutlet UITextView *hideNum;
}
@property (nonatomic, retain) UIImageView *usrImage;
@property (nonatomic, retain) UITextView *usrName;
@property (nonatomic, retain) UITextView *usrPart;

@property (nonatomic, retain) UITextView *usrTip;
@end
