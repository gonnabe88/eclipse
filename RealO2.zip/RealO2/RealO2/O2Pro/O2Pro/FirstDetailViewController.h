//
//  FirstDetailViewController.h
//  O2Pro
//
//  Created by JANG on 13. 1. 13..
//  Copyright (c) 2013년 JANG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FirstDetailViewController : UIViewController
{
    IBOutlet UIImageView *usrImage;
    IBOutlet UITextView *usrName;
    IBOutlet UITextView *usrPart;
    
    IBOutlet UITextView *hideNum;
}
@property (nonatomic, retain) UIImageView *tempImage;
@property (nonatomic, retain) UITextView *tempName;
@property (nonatomic, retain) UITextView *tempPart;

@property (nonatomic, retain) UITextView *tempTip;
@end
