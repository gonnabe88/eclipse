//
//  FirstViewController.h
//  O2Pro
//
//  Created by JANG on 13. 1. 13..
//  Copyright (c) 2013년 JANG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FirstViewController : UIViewController<UITableViewDelegate,
UITableViewDataSource> {
    UITableView *tView;
    NSArray *photoArray;
    
    
}

@property(retain, nonatomic) IBOutlet UITableView *tView;
@property(readonly) IBOutlet NSArray *photoArray;
@property(retain, nonatomic) NSString *check;
-(NSArray *)createPhotoData;


@end
