//
//  FirstDetailViewController.m
//  O2Pro
//
//  Created by JANG on 13. 1. 13..
//  Copyright (c) 2013년 JANG. All rights reserved.
//

#import "FirstDetailViewController.h"

@interface FirstDetailViewController ()

@end

@implementation FirstDetailViewController
@synthesize tempName, tempPart, tempImage;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    self.navigationController.title = tempName.text;
    usrImage.image = tempImage.image;
    usrName.text = tempName.text;
    usrPart.text = tempPart.text;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
