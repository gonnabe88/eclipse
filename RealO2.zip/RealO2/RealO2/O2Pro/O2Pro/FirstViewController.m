//
//  FirstViewController.m
//  O2Pro
//
//  Created by JANG on 13. 1. 13..
//  Copyright (c) 2013년 JANG. All rights reserved.
//

#import "FirstViewController.h"
#import "ViewCell.h"
#import "FirstDetailViewController.h"

@interface FirstViewController ()

@end

@implementation FirstViewController


@synthesize tView, photoArray, check;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    tView.delegate = self;
    tView.dataSource = self;
    photoArray = [[NSArray alloc] initWithArray:[self createPhotoData]];
}

-(NSArray *)createPhotoData{
    NSArray *array;
    UIImage *thumbnail;
    
    thumbnail = [UIImage imageNamed:@"r2.jpg"];
    NSDictionary *a = [NSDictionary dictionaryWithObjectsAndKeys:thumbnail,@"thumbnail",
                       @"Rihanna1",@"name",
                       @"Photo1",@"part",nil];
    thumbnail = [UIImage imageNamed:@"r6.jpg"];
    NSDictionary *b = [NSDictionary dictionaryWithObjectsAndKeys:thumbnail,@"thumbnail",
                       @"Rihanna2",@"name",
                       @"Photo2",@"part",nil];
    
    array = [NSArray arrayWithObjects:a,b, nil];
    
    return array;
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    //#warning Incomplete method implementation.
    // Return the number of rows in the section.
    return [photoArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    ViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    // Configure the cell...
    
    NSDictionary *photoData = [photoArray objectAtIndex:[indexPath row]];
    cell.usrImage.image = [photoData valueForKey:@"thumbnail"];
    cell.usrName.text = [photoData valueForKey:@"name"];
    cell.usrPart.text = [photoData valueForKey:@"part"];
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 80.0f;
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString:@"Detail"]) {
        FirstDetailViewController *DetailedViewController = (FirstDetailViewController *)[segue destinationViewController];
        DetailedViewController.tempImage = ((ViewCell *)sender).usrImage;
        DetailedViewController.tempName = ((ViewCell *)sender).usrName;
        
    }
}

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Navigation logic may go here. Create and push another view controller.
    /*
     <#DetailViewController#> *detailViewController = [[<#DetailViewController#> alloc] initWithNibName:@"<#Nib name#>" bundle:nil];
     // ...
     // Pass the selected object to the new view controller.
     [self.navigationController pushViewController:detailViewController animated:YES];
     */
}


@end
